import cv2
import numpy as np

# Define color ranges in HSV (Hue, Saturation, Value) space
COLOR_RANGES = {
    "red": [(0, 120, 70), (10, 255, 255)],        # Lower range for red
    "red2": [(170, 120, 70), (180, 255, 255)],    # Upper range for red (HSV wrap-around)
    "green": [(36, 50, 70), (89, 255, 255)],      # Range for green
    "blue": [(94, 80, 2), (126, 255, 255)]        # Range for blue
}

# Assign unique colors for bounding boxes
BOUNDING_BOX_COLORS = {
    "red": (0, 0, 255),  
    "green": (0, 255, 0),  
    "blue": (255, 0, 0)   
}


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not access the camera.")
    exit()

# Define center region (Region of Interest - ROI)
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Define the center region dimensions
roi_width = 390  # Width of the region where detection is allowed
roi_height = 360  # Height of the region where detection is allowed
roi_x = (frame_width - roi_width) // 2  # X-coordinate of the top-left corner of ROI
roi_y = (frame_height - roi_height) // 2  # Y-coordinate of the top-left corner of ROI


cv2.namedWindow("Color Detection", cv2.WINDOW_NORMAL)

# Capture each frame
while True:   
    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read frame.")
        break

    # Convert the frame to HSV color space
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Variables to store the largest contour and color name
    largest_contour = None
    largest_area = 0
    color_name = None

    for color_name_key, (lower_range, upper_range) in COLOR_RANGES.items():
        # Convert color ranges to NumPy arrays
        lower = np.array(lower_range, dtype=np.uint8)
        upper = np.array(upper_range, dtype=np.uint8)

        # Create a mask for the color
        mask = cv2.inRange(hsv_frame, lower, upper)

        # Find contours from the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Find the largest contour by area
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 500:  # Ignore small contours
                if area > largest_area:  # Compare to the largest found so far
                    largest_area = area
                    largest_contour = contour
                    color_name = color_name_key

    if largest_contour is not None:
        # Draw a bounding box around the largest detected object
        x, y, w, h = cv2.boundingRect(largest_contour)
        
        # Check if the bounding box is inside the defined center region (ROI)
        if (x + w // 2) >= roi_x and (x + w // 2) <= (roi_x + roi_width) and \
           (y + h // 2) >= roi_y and (y + h // 2) <= (roi_y + roi_height):
            # If the center of the object is in the center region (ROI), draw the bounding box
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), BOUNDING_BOX_COLORS.get(color_name.split("2")[0], (255, 255, 255)), 2)
            cv2.putText(frame, color_name.split("2")[0], (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, BOUNDING_BOX_COLORS.get(color_name.split("2")[0], (255, 255, 255)), 2)

    # Draw a rectangle around the center region (ROI) for visualization
    cv2.rectangle(frame, (roi_x, roi_y), (roi_x + roi_width, roi_y + roi_height), (255, 255, 0), 2)  # Yellow ROI box

    # Show the frame with the largest object detected (if within the center region)
    cv2.imshow("Color Detection", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()
