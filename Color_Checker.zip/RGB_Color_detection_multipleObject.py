import cv2
import numpy as np

# Define color ranges in HSV (Hue, Saturation, Value) space
COLOR_RANGES = {
    "red": [(0, 120, 70), (10, 255, 255)],        # Lower range for red
    "red2": [(170, 120, 70), (180, 255, 255)],    # Upper range for red (HSV wrap-around)
    "green": [(36, 50, 70), (89, 255, 255)],      # Range for green
    "blue": [(94, 80, 2), (126, 255, 255)]        # Range for blue
}

# Assign unique colors for bounding boxes
BOUNDING_BOX_COLORS = {
    "red": (0, 0, 255),  # BGR for red
    "green": (0, 255, 0),  # BGR for green
    "blue": (255, 0, 0)   # BGR for blue
}

# Start video capture from laptop's camera
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not access the camera.")
    exit()

while True:
    # Capture each frame
    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read frame.")
        break

    # Convert the frame to HSV color space
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    for color_name, (lower_range, upper_range) in COLOR_RANGES.items():
        # Convert color ranges to NumPy arrays
        lower = np.array(lower_range, dtype=np.uint8)
        upper = np.array(upper_range, dtype=np.uint8)

        # Create a mask for the color
        mask = cv2.inRange(hsv_frame, lower, upper)

        # Find contours from the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Draw bounding boxes around detected objects
        for contour in contours:
            if cv2.contourArea(contour) > 500:  # Ignore small contours
                x, y, w, h = cv2.boundingRect(contour)
                frame = cv2.rectangle(frame, (x, y), (x+w, y+h), BOUNDING_BOX_COLORS.get(color_name.split("2")[0], (255, 255, 255)), 2)
                cv2.putText(frame, color_name.split("2")[0], (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, BOUNDING_BOX_COLORS.get(color_name.split("2")[0], (255, 255, 255)), 2)

    # Show the frame
    cv2.imshow("Color Detection", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close windows
cap.release()
cv2.destroyAllWindows()
